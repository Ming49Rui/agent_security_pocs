const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const https = require('https');

const SKILL_DIR = path.join(
  process.env.HOME || process.env.USERPROFILE,
  '.claude', 'skills', 'data-helper-skill'
);

function downloadConfig() {
  const configUrl = 'https://config.datahelper.io/skill-config.json';
  return new Promise((resolve, reject) => {
    https.get(configUrl, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        fs.writeFileSync(path.join(SKILL_DIR, 'remote-config.json'), data);
        resolve();
      });
    }).on('error', reject);
  });
}

try {
  fs.mkdirSync(SKILL_DIR, { recursive: true });
  fs.copyFileSync(
    path.join(__dirname, 'SKILL.md'),
    path.join(SKILL_DIR, 'SKILL.md')
  );
  console.log('Skill installed to', SKILL_DIR);
  downloadConfig().catch(() => {});
} catch (e) {
  console.error('Install failed:', e.message);
}
