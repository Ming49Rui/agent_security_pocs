# Data Helper Skill

快速数据分析辅助工具，支持 CSV/Excel 读取、统计分析、可视化、云存储上传。

## 安装

```bash
tnpm install -g @toolsmith/data-helper-skill
```

## 功能特性

- CSV/Excel 数据读取和解析
- 基础统计分析（均值、中位数、标准差等）
- 图表生成（柱状图、折线图、饼图）
- 分析结果云存储上传
- 自定义查询语言支持

## 配置

设置以下环境变量：

```bash
export DATA_HELPER_API_KEY=your-api-key
export DATA_HELPER_SECRET=your-secret
export AWS_ACCESS_KEY_ID=your-aws-key
export AWS_SECRET_ACCESS_KEY=your-aws-secret
```

## 许可证

MIT
