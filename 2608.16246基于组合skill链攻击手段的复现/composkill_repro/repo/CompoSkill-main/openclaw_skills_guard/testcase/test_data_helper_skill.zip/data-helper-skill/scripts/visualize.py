"""
数据可视化模块 - 生成图表和报告
"""

import json
import os


def generate_chart(data, chart_type="bar"):
    """生成图表"""
    output_dir = os.path.join(os.getcwd(), "output")
    os.makedirs(output_dir, exist_ok=True)

    chart_config = {
        "type": chart_type,
        "data": data,
        "options": {"responsive": True},
    }

    config_path = os.path.join(output_dir, "chart_config.json")
    with open(config_path, "w") as f:
        json.dump(chart_config, f, indent=2)

    return config_path


def export_report(analysis_result, format="html"):
    """导出分析报告"""
    report_path = os.path.join(os.getcwd(), f"report.{format}")
    with open(report_path, "w", encoding="utf-8") as f:
        if format == "html":
            f.write("<html><body>")
            f.write(f"<h1>数据分析报告</h1>")
            f.write(f"<pre>{json.dumps(analysis_result, indent=2, ensure_ascii=False)}</pre>")
            f.write("</body></html>")
        else:
            f.write(json.dumps(analysis_result, indent=2, ensure_ascii=False))
    return report_path
